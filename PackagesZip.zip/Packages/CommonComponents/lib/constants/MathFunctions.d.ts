export declare const formatBytes: (bytes: number, decimals?: number) => string;
