const isNullOrWhiteSpace = (string: string) => {
  if (!string || string.trim().length === 0) {
    return true;
  } else {
    return false;
  }
};

export default isNullOrWhiteSpace;
