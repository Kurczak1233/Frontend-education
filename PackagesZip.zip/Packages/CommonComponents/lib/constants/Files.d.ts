export declare const maxFileSizeInBytes = 10485760;
export declare const imageExtensions: string[];
export declare const acceptedFileExtensions: string[];
export declare const acceptedFilesExtensionsToDisplay = "JPG, PNG, MS OFFICE, PDF";
