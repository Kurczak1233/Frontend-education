/// <reference types="react" />
import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";
import "./UploadOverviewImagesComponent.scss";
interface IUploadOverviewImagesComponents {
    previews: HasPreviewItem[];
}
declare const UploadOverviewImagesComponent: ({ previews, }: IUploadOverviewImagesComponents) => JSX.Element;
export default UploadOverviewImagesComponent;
