// 10 MB
export const maxFileSizeInBytes = 10485760;

export const imageExtensions = ["image/jpeg", "image/png"];

const wordExtensions = [
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];
const excelExtensions = [
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
];
const powerPointExtensions = [
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
];
const msOfficeExtensions = [
  ...wordExtensions,
  ...excelExtensions,
  ...powerPointExtensions,
];

export const acceptedFileExtensions = [
  ...imageExtensions,
  ...msOfficeExtensions,
  "application/pdf",
];

export const acceptedFilesExtensionsToDisplay = "JPG, PNG, MS OFFICE, PDF";
