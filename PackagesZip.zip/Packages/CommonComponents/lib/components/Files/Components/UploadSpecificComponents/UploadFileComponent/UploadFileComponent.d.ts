/// <reference types="react" />
import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";
interface IUploadFileButton {
    setMyFiles: React.Dispatch<React.SetStateAction<File[]>>;
    myFiles: File[];
    setPreviews: React.Dispatch<React.SetStateAction<HasPreviewItem[]>>;
    previews: HasPreviewItem[];
    serachButton: JSX.Element;
}
declare const UploadFileComponent: ({ setMyFiles, myFiles, serachButton, previews, setPreviews, }: IUploadFileButton) => JSX.Element;
export default UploadFileComponent;
