import "./EmptyWithLabelAndArrow.scss";
import GrayDropdownDownArrow from "./GrayDropdownDownArrow.svg";

interface InputWithLabel {
  label: string;
  containerPlaceholder: string;
  marginTop?: number;
  marginBottom?: number;
  isActive?: boolean;
  onClick: () => void;
}

const EmptyWithLabelAndArrow = ({
  label,
  containerPlaceholder,
  marginTop,
  marginBottom,
  isActive,
  onClick,
}: InputWithLabel) => {
  return (
    <div
      className={"common-components__empty-with-label-and-arrow-wrapper"}
      style={{
        marginTop: marginTop,
        marginBottom: marginBottom,
      }}
      onClick={onClick}
    >
      <div className={"common-components__empty-with-label-and-arrow"}>
        <span>{label}</span>
      </div>
      <div className={"common-components__empty-with-label-and-arrow-input"}>
        {isActive ? (
          <span className="common-components__empty-label--green">
            Chosen some values
          </span>
        ) : (
          <>
            <span>{containerPlaceholder}</span>
            <img src={GrayDropdownDownArrow} alt="Down dropdown icon" />
          </>
        )}
      </div>
    </div>
  );
};

export default EmptyWithLabelAndArrow;
