/// <reference types="react" />
import "./UploadedImagesButton.scss";
import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";
interface IUploadedImagesButton {
    marginTop?: number;
    marginBottom?: number;
    setPreviews: React.Dispatch<React.SetStateAction<HasPreviewItem[]>>;
    previews: HasPreviewItem[];
    setMyFiles: React.Dispatch<React.SetStateAction<File[]>>;
    myFiles: File[];
}
declare const UploadedImagesButton: ({ marginTop, marginBottom, setPreviews, previews, setMyFiles, myFiles, }: IUploadedImagesButton) => JSX.Element;
export default UploadedImagesButton;
