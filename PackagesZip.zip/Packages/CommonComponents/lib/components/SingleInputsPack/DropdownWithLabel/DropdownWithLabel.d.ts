/// <reference types="react" />
import "./DropdownWithLabel.scss";
interface IDropdownWithLabel {
    label: string;
    marginTop?: number;
    marginBottom?: number;
    SelectComponent: JSX.Element;
    required?: boolean;
}
declare const DropdownWithLabel: ({ label, marginTop, marginBottom, SelectComponent, required, }: IDropdownWithLabel) => JSX.Element;
export default DropdownWithLabel;
