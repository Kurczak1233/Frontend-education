export declare const dropdownStyles: {
    control: (provided: any, { isFocused }: any) => any;
    indicatorSeparator: () => {
        display: string;
    };
    dropdownIndicator: (provided: any) => any;
    input: (provided: any) => any;
    placeholder: (provided: any) => any;
    option: (styles: any) => any;
    singleValue: (styles: any) => any;
};
