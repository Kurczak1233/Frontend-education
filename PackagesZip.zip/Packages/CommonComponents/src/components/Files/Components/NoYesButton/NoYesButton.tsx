
import { grayBackground, grayText, greenText, lightGreen } from "../../../../constants/JsColors";
import "./NoYesButton.scss";

interface INoYesButton {
  text: "YES" | "NO";
  onClick: () => void;
}

const NoYesButton = ({ text, onClick }: INoYesButton) => {
  return (
    <div
      onClick={onClick}
      className={"common-components__yes-no-button"}
      style={{
        color: text === "YES" ? greenText : grayText,
        background: text === "YES" ? lightGreen : grayBackground,
      }}
    >
      {text}
    </div>
  );
};

export default NoYesButton;
