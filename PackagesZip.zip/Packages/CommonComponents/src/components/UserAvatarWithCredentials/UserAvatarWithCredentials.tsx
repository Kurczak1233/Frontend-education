import UserAvatar from "../UserAvatar/UserAvatar";
import "./UserAvatarWithCredentials.scss";

interface IUserAvatarWithCredentials {
  validatedUserCredentials: string;
  role: string;
  width?: string;
  showOrganizationRole?: boolean;
  hideSubTitle?: boolean;
}

const UserAvatarWithCredentials = ({
  validatedUserCredentials,
  role,
  width = "auto",
  showOrganizationRole = false,
  hideSubTitle = false,
}: IUserAvatarWithCredentials) => {
  return (
    <div
      className="common-components__responsible-user-avatar-and-credentials"
      style={{ width: width }}
    >
      <UserAvatar displayName={validatedUserCredentials} size={32} />
      <div className="common-components__responsible-user-credentials">
        <div>{validatedUserCredentials}</div>
        <div>
          {!hideSubTitle && (
            <>{showOrganizationRole ? "Organization" : "Team"}</>
          )}
          {role}
        </div>
      </div>
    </div>
  );
};

export default UserAvatarWithCredentials;
