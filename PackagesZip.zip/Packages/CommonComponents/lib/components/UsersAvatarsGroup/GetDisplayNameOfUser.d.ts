export declare const getDisplayNameOfUser: (firstName: string, lastName: string, email: string) => string;
