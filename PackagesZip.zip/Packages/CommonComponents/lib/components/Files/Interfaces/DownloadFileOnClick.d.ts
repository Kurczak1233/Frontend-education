import { DownloadedFile } from "./DownloadedFile";
export declare const downloadFileOnClick: (myFile: DownloadedFile) => void;
