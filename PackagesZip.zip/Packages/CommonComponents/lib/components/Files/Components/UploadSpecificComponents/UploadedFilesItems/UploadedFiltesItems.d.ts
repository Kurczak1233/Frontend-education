/// <reference types="react" />
import "./UploadedFilesItems.scss";
interface IUploadedFilesItems {
    myFiles: File[];
    removeFile: (file: File) => void;
}
declare const UploadedFilesItems: ({ myFiles, removeFile }: IUploadedFilesItems) => JSX.Element;
export default UploadedFilesItems;
