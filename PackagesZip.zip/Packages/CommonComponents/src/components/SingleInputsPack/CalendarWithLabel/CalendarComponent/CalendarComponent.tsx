import React, { useEffect, useRef } from "react";
import DatePicker, { registerLocale } from "react-datepicker";
import "./CalendarComponent.scss";
import enGB from "date-fns/locale/en-GB";

interface ICalendarComponent {
  isOpen: boolean;
  isOpenSetter: React.Dispatch<React.SetStateAction<boolean>>;
  date: Date | null;
  onSaveClick: (date: Date | null) => void;
}

const CalendarComponent = ({
  isOpen,
  isOpenSetter,
  date,
  onSaveClick,
}: ICalendarComponent) => {
  const calendarRef = useRef<HTMLDivElement>(null);

  registerLocale("en-gb", enGB);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const checkIfClickedOutside = (e: { target: any }) => {
      if (
        isOpen &&
        calendarRef.current &&
        !calendarRef.current.contains(e.target)
      ) {
        isOpenSetter(false);
      }
    };
    document.addEventListener("mousedown", checkIfClickedOutside);
    return () => {
      document.removeEventListener("mousedown", checkIfClickedOutside);
    };
  }, [isOpen]);

  return (
    <React.Fragment>
      {isOpen && (
        <div
          data-testid="calendarComponent"
          ref={calendarRef}
          className={"common-components__calendar-component-wrapper"}
        >
          <div
            className={
              "common-components__calendar-component-datepicker-wrapper"
            }
          >
            <DatePicker
              locale={"en-gb"}
              selected={date ? new Date(date) : new Date()}
              inline
              onChange={(date) => {
                onSaveClick(date);
                isOpenSetter(false);
              }}
              formatWeekDay={(nameOfDay) => nameOfDay.substr(0, 1)}
              disabledKeyboardNavigation
            />
          </div>
        </div>
      )}
    </React.Fragment>
  );
};

export default CalendarComponent;
