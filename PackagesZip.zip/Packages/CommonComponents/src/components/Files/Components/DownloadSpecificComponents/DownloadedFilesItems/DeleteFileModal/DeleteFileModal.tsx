import FileIcon from "../../../../../../constants/FileIcon/FileIcon";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
import NoYesButton from "../../../NoYesButton/NoYesButton";
import "./DeleteFileModal.scss";

interface IDeleteFileModal {
  removeFile: (file: DownloadedFile) => void;
  myFile: DownloadedFile;
  setIsFileDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>;
  handleCloseDeleteModal: () => void;
  setIsDeleteFileModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  handleCloseOverviewModal?: () => void;
}

const DeleteFileModal = ({
  removeFile,
  myFile,
  setIsFileDropdownOpen,
  handleCloseDeleteModal,
  setIsDeleteFileModalOpen,
  handleCloseOverviewModal,
}: IDeleteFileModal) => {
  const handleRemoveFile = () => {
    setIsFileDropdownOpen(false);
    setIsDeleteFileModalOpen(false);
    if (handleCloseOverviewModal) {
      handleCloseOverviewModal();
    }
    removeFile(myFile);
  };

  return (
    <div className="common-components__delete-file-modal--wrapper">
      <div className="common-components__delete-file-upper-text">
        Are you sure you want to delete that file?
      </div>
      <div className="common-components__delete-file-details">
        <FileIcon contentType={myFile.imageDetails.contentType} />
        {myFile.imageDetails.fileDownloadName}
      </div>
      <div className="common-components__confirm-or-reject-buttons">
        <NoYesButton text={"NO"} onClick={handleCloseDeleteModal} />
        <NoYesButton text={"YES"} onClick={handleRemoveFile} />
      </div>
    </div>
  );
};

export default DeleteFileModal;
