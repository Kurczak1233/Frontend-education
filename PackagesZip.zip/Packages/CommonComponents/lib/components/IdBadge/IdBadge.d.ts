/// <reference types="react" />
import "./IdBadge.scss";
interface IIdBadge {
    id: number;
}
declare const IdBadge: ({ id }: IIdBadge) => JSX.Element;
export default IdBadge;
