export interface HasPreviewItem {
  preview: string;
  name: string;
  size: number;
  lastModified: number;
}
