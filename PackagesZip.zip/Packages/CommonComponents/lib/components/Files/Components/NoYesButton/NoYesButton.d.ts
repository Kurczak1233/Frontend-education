/// <reference types="react" />
import "./NoYesButton.scss";
interface INoYesButton {
    text: "YES" | "NO";
    onClick: () => void;
}
declare const NoYesButton: ({ text, onClick }: INoYesButton) => JSX.Element;
export default NoYesButton;
