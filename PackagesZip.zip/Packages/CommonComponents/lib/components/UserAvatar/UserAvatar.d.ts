/// <reference types="react" />
interface IUserAvatar {
    displayName: string;
    size: number;
}
declare const UserAvatar: ({ displayName, size }: IUserAvatar) => JSX.Element;
export default UserAvatar;
