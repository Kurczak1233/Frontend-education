import "./IdBadge.scss";

interface IIdBadge {
  id: number;
}

const IdBadge = ({ id }: IIdBadge) => {
  return (
    <div className={"common-components__id-badge"}>
      <span>{id}</span>
    </div>
  );
};

export default IdBadge;
