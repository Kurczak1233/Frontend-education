export interface ImageDetails {
  contentType: string;
  enableRangeProcessing: boolean;
  entityTag: string;
  fileContents: File | Blob;
  fileDownloadName: string;
}