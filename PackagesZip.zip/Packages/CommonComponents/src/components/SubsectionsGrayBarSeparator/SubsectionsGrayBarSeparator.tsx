import "./SubsectionsGrayBarSeparator.scss";

interface ISubsectionsGrayBarSeparator {
  text: string;
  marginTop?: number;
  marginBottom?: number;
}

const SubsectionsGrayBarSeparator = ({
  text,
  marginTop,
  marginBottom,
}: ISubsectionsGrayBarSeparator) => {
  return (
    <div
      style={{ marginTop: marginTop, marginBottom: marginBottom }}
      className="common-components__gray-bar-separator"
    >
      {text}
    </div>
  );
};

export default SubsectionsGrayBarSeparator;
