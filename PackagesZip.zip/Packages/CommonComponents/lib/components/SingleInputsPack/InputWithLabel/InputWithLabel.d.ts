/// <reference types="react" />
import { FieldError, UseFormRegister } from "react-hook-form";
import "./InputWithLabel.scss";
interface IInputWithLabel {
    label: any;
    labelWithVariables?: string;
    inputPlaceholder: string;
    showCalendarIcon?: boolean;
    isFirstCalendarInput?: boolean;
    marginTop?: number;
    marginBottom?: number;
    showSignsCounter?: boolean;
    maxInputLength?: number;
    type?: string;
    register: UseFormRegister<any>;
    requirements?: any;
    fieldError?: FieldError | undefined;
    errorText?: string;
    value?: string | number;
    registerName?: string;
    onValueChange?: (value: string) => void;
    onBlur?: (value: string, index?: number) => void;
    min?: number;
    pattern?: string;
    index?: number;
    inputMode?: string;
    fontSize?: number;
    labelSize?: number;
    disabled?: boolean;
    width?: number;
    height?: string;
    required?: boolean;
    datacy?: string;
}
declare const InputWithLabel: ({ label, labelWithVariables, inputPlaceholder, showCalendarIcon, isFirstCalendarInput, marginTop, marginBottom, showSignsCounter, maxInputLength, register, fieldError, errorText, requirements, type, value, registerName, onValueChange, min, onBlur, index, pattern, inputMode, fontSize, labelSize, disabled, height, width, required, datacy, }: IInputWithLabel) => JSX.Element;
export default InputWithLabel;
