/// <reference types="react" />
import "./CalendarWithLabel.scss";
interface ICalendarWithLabel {
    date: Date | null;
    handleSetDate: (date: Date | null) => void;
    label: string;
    marginBottom?: number;
    marginTop?: number;
}
declare const CalendarWithLabel: ({ date, handleSetDate, label, marginBottom, marginTop, }: ICalendarWithLabel) => JSX.Element;
export default CalendarWithLabel;
