import { DownloadedFile } from "./DownloadedFile";

export const downloadFileOnClick = (myFile: DownloadedFile) => {
  const link = document.createElement("a");
  link.href = `data:image/png;base64,${myFile.imageDetails.fileContents}`;
  link.download = myFile.imageDetails.fileDownloadName;
  link.click();
};
