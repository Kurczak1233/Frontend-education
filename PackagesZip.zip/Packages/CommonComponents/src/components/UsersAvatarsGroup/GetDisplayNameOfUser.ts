import isNullOrWhiteSpace from "./IsNullOrEmpty";

export const getDisplayNameOfUser = (
  firstName: string,
  lastName: string,
  email: string
) => {
  if (isNullOrWhiteSpace(firstName) || isNullOrWhiteSpace(lastName)) {
    return `${email}`;
  }

  return `${firstName} ${lastName}`;
};
