/// <reference types="react" />
import "./DownloadedFileItem.scss";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
interface IDownloadedFilesItems {
    myFile: DownloadedFile;
    isReadonly: boolean;
    removeFile: (file: DownloadedFile) => void;
    showDropdown?: boolean;
    hasPermissionToEdit: boolean;
    setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
    organizationId: number;
    updateFileName(id: string, fileName: string, organizationId: number): Promise<null>;
}
declare const DownloadedFileItem: ({ myFile, removeFile, isReadonly, showDropdown, hasPermissionToEdit, setOtherFiles, organizationId, updateFileName, }: IDownloadedFilesItems) => JSX.Element;
export default DownloadedFileItem;
