/// <reference types="react" />
import "./FileOptionsDropdown.scss";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
interface IFileOptionsDropdown {
    myFile: DownloadedFile;
    setIsFileDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>;
    handleOpenDeleteModal: () => void;
}
declare const FileOptionsDropdown: ({ myFile, setIsFileDropdownOpen, handleOpenDeleteModal, }: IFileOptionsDropdown) => JSX.Element;
export default FileOptionsDropdown;
