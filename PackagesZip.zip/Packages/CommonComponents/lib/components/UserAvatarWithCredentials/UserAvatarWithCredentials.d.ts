/// <reference types="react" />
import "./UserAvatarWithCredentials.scss";
interface IUserAvatarWithCredentials {
    validatedUserCredentials: string;
    role: string;
    width?: string;
    showOrganizationRole?: boolean;
    hideSubTitle?: boolean;
}
declare const UserAvatarWithCredentials: ({ validatedUserCredentials, role, width, showOrganizationRole, hideSubTitle, }: IUserAvatarWithCredentials) => JSX.Element;
export default UserAvatarWithCredentials;
