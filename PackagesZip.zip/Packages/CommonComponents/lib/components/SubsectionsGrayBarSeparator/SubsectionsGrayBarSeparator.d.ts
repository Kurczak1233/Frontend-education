/// <reference types="react" />
import "./SubsectionsGrayBarSeparator.scss";
interface ISubsectionsGrayBarSeparator {
    text: string;
    marginTop?: number;
    marginBottom?: number;
}
declare const SubsectionsGrayBarSeparator: ({ text, marginTop, marginBottom, }: ISubsectionsGrayBarSeparator) => JSX.Element;
export default SubsectionsGrayBarSeparator;
