import {
  Control,
  FieldError,
  FieldValues,
  UseFormRegister,
} from "react-hook-form";
import "./DropdownWithLabel.scss";

interface IDropdownWithLabel {
  label: string;
  marginTop?: number;
  marginBottom?: number;
  SelectComponent: JSX.Element;
  required?: boolean;
}

const DropdownWithLabel = ({
  label,
  marginTop,
  marginBottom,
  SelectComponent,
  required = false,
}: IDropdownWithLabel) => {
  return (
    <div
      className={"common-components__dropdown-with-label-wrapper"}
      style={{ marginTop: marginTop, marginBottom: marginBottom }}
    >
      <div className={"common-components__dropdown-with-label-label"}>
        <span>{label}{required && <span className="common-components__required-star">*</span>}</span>
      </div>
      {SelectComponent}
    </div>
  );
};

export default DropdownWithLabel;
