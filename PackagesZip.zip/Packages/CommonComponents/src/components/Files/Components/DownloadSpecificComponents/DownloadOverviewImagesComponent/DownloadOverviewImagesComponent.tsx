import { DownloadedFile } from "../../../Interfaces/DownloadedFile";
import DownloadOverviewImage from "./DownloadOverviewImage/DownloadOverviewImage";
import "./DownloadOverviewImagesComponent.scss";

interface IDownloadOverviewImagesComponent {
  myFiles: DownloadedFile[];
  marginTop?: number;
  marginBottom?: number;
  removeFile: (file: DownloadedFile) => void;
  isReadonly?: boolean;
  setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
  organizationId: number;
  hasPermissionToEdit?: boolean;
  updateFileName(id: string, fileName: string, organizationId: number): Promise<null>;
}

const DownloadOverviewImagesComponent = ({
  myFiles,
  marginBottom,
  marginTop,
  removeFile,
  organizationId,
  setOtherFiles,
  isReadonly = false,
  hasPermissionToEdit = true,
  updateFileName,
}: IDownloadOverviewImagesComponent) => {
  const updateFile = async (file: DownloadedFile, newName: string) => {
    setOtherFiles((oldImages) => {
      const foundImage = oldImages.find((item) => item.guid === file.guid);
      if (foundImage) {
        foundImage.imageDetails.fileDownloadName = newName;
      }
      return [...oldImages];
    });
    await updateFileName(file.guid, newName, +organizationId);
  };

  return (
    <div
      className="common-components__images-wrapper"
      style={{
        marginBottom: marginBottom,
        marginTop: marginTop,
        height: myFiles.length > 0 ? 136 : 36,
      }}
    >
      <span className="common-components__images-no-items">
        {myFiles.length === 0 && "None"}
      </span>
      {myFiles.map((item) => {
        return (
          <DownloadOverviewImage
            myFile={item}
            removeFile={removeFile}
            updateFile={updateFile}
            isReadonly={isReadonly}
            hasPermissionToEdit={hasPermissionToEdit}
            key={`data:image/png;base64,${item.imageDetails.fileContents}`}
          />
        );
      })}
    </div>
  );
};

export default DownloadOverviewImagesComponent;
