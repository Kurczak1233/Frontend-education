import GreenThreeDotsIcon from "../../../../../../public/GreenThreeDotsIcon.svg";
import Modal from "react-modal";
import ThreeDotsIcon from "../../../../../../public/ThreeDotsIcon.svg";
import DeleteFileModal from "../DeleteFileModal/DeleteFileModal";
import FileOptionsDropdown from "../FileOptionsDropdown/FileOptionsDropdown";
import { useState } from "react";
import "./DownloadedFileItem.scss";
import FileIcon from "../../../../../../constants/FileIcon/FileIcon";
import DropdownWrapper from "../../../../../DropdownWrapper/DropdownWrapper";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
import DownloadIcon from "../../../../../../public/DownloadIcon.svg";
import TrashCanIcon from "../../../../../../public/TrashCanIcon.svg";
import { downloadFileOnClick } from "../../../../Interfaces/DownloadFileOnClick";
interface IDownloadedFilesItems {
  myFile: DownloadedFile;
  isReadonly: boolean;
  removeFile: (file: DownloadedFile) => void;
  showDropdown?: boolean;
  hasPermissionToEdit: boolean;
  setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
  organizationId: number;
  updateFileName(
    id: string,
    fileName: string,
    organizationId: number
  ): Promise<null>;
}

const DownloadedFileItem = ({
  myFile,
  removeFile,
  isReadonly,
  showDropdown,
  hasPermissionToEdit,
  setOtherFiles,
  organizationId,
  updateFileName,
}: IDownloadedFilesItems) => {
  const [isFileDropdownOpen, setIsFileDropdownOpen] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>(
    myFile.imageDetails.fileDownloadName
  );
  const [isDeleteFileModalOpen, setIsDeleteFileModalOpen] =
    useState<boolean>(false);

  const updateFile = async (file: DownloadedFile, newName: string) => {
    setOtherFiles((oldFiles) => {
      const foundImage = oldFiles.find((item) => item.guid === file.guid);
      if (foundImage) {
        foundImage.imageDetails.fileDownloadName = newName;
      }
      return [...oldFiles];
    });
    await updateFileName(file.guid, newName, +organizationId);
  };

  const openFileDropdown = () => {
    setIsFileDropdownOpen(true);
  };

  const handleCloseDeleteModal = () => {
    setIsDeleteFileModalOpen(false);
  };

  const handleOpenDeleteModal = () => {
    setIsDeleteFileModalOpen(true);
  };

  const handleRemoveFile = () => {
    removeFile(myFile);
  };

  const handleDownloadFile = () => {
    downloadFileOnClick(myFile);
  };

  return (
    <div className="common-components__downloaded-files-item">
      <div className="common-components__downloaded-files-item--left">
        <FileIcon contentType={myFile.imageDetails.contentType} />
        {hasPermissionToEdit ? (
          <input
            className="common-components__downloaded-files-input--wrapper"
            placeholder={"File name..."}
            value={fileName}
            onChange={(e) => {
              setFileName(e.target.value);
            }}
            onBlur={(e) => {
              updateFile(myFile, e.target.value);
            }}
          />
        ) : (
          <div className="common-components__downloaded-files-heading-title">
            <span>{myFile.imageDetails.fileDownloadName}</span>
          </div>
        )}
      </div>
      <Modal
        isOpen={isDeleteFileModalOpen}
        onRequestClose={handleCloseDeleteModal}
        className={"common-components__delete-file-modal"}
        overlayClassName={"common-components__delete-file-modal-overlay"}
        ariaHideApp={false}
      >
        <DeleteFileModal
          removeFile={removeFile}
          myFile={myFile}
          setIsDeleteFileModalOpen={setIsDeleteFileModalOpen}
          handleCloseDeleteModal={handleCloseDeleteModal}
          setIsFileDropdownOpen={setIsFileDropdownOpen}
        />
      </Modal>
      {!isReadonly && (
        <div className="common-components__downloaded-files-item--right">
          {showDropdown ? (
            <DropdownWrapper
              isOpen={isFileDropdownOpen}
              setIsOpen={setIsFileDropdownOpen}
              dropdownContent={
                <FileOptionsDropdown
                  handleOpenDeleteModal={handleOpenDeleteModal}
                  myFile={myFile}
                  setIsFileDropdownOpen={setIsFileDropdownOpen}
                />
              }
              dropdownContainer={
                <img
                  src={isFileDropdownOpen ? GreenThreeDotsIcon : ThreeDotsIcon}
                  alt="Trash icon"
                  onClick={openFileDropdown}
                  className="common-components__downloaded-files-item--icon"
                />
              }
            />
          ) : (
            <div className="common-components__downloaded-files-item--icons">
              <img
                src={DownloadIcon}
                alt={"Download icon"}
                onClick={handleDownloadFile}
              />
              <img
                src={TrashCanIcon}
                alt={"Delete icon"}
                onClick={handleRemoveFile}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DownloadedFileItem;
