/// <reference types="react" />
interface IFileIcon {
    contentType: string;
}
declare const FileIcon: ({ contentType }: IFileIcon) => JSX.Element;
export default FileIcon;
