/// <reference types="react" />
import "./UsersAvatarsGroup.scss";
interface IUsersAvatarsGroup {
    size: number;
    users: {
        firstName: string;
        lastName: string;
        email: string;
    }[];
    maxAvatarsNumber: number;
}
declare const UsersAvatarsGroup: ({ size, users, maxAvatarsNumber, }: IUsersAvatarsGroup) => JSX.Element;
export default UsersAvatarsGroup;
