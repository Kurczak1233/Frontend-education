import { FieldError, UseFormRegister } from "react-hook-form";
import ErrorText from "../../ErrorText/ErrorText";
import "./BorderedTextAreaDescriptionComponent.scss";

interface IBorderedTextAreaDescriptionComponent {
  marginTop?: number;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register: UseFormRegister<any>;
  requirements?: any;
  registerName?: string;
  marginBottom?: number;
  hideLabel?: boolean;
  disabled?: boolean; 
  label: string;
  fontSize?: number;
  labelSize?: number;
  width?: number;
  height?: number;
  fieldError?: FieldError | undefined;
  errorText?: string;
  required?: boolean;
  datacy?: string;
}

const BorderedTextAreaDescriptionComponent = ({
  marginBottom,
  marginTop,
  register,
  requirements,
  registerName,
  label,
  fontSize = 14,
  labelSize = 14,
  height = 116,
  hideLabel = false,
  disabled = false,
  width,
  fieldError,
  errorText,
  required = false,
  datacy,
}: IBorderedTextAreaDescriptionComponent) => {
  return (
    <div
      style={{
        marginTop: marginTop,
        marginBottom: marginBottom,
      }}
    >
      {!hideLabel && (
        <div
          style={{ fontSize: labelSize }}
          className={"common-components__bordered-description"}
        >
          <span>
          {label}
          {required && <span className="common-components__required-star">*</span>}
          </span>
        </div>
      )}
      <textarea
        data-cy={datacy}
        style={{
          fontSize: fontSize,
          width: width ? `${width}px` : "100%",
          height: `${height}px`,
        }}
        className={"common-components__bordered-description-textarea"}
        placeholder={"Enter your description here"}
        {...register(registerName ? registerName : label, requirements)}
        disabled={disabled}
      />
      <ErrorText
        isVisible={fieldError !== undefined}
        text={errorText ? errorText : ""}
      />
    </div>
  );
};

export default BorderedTextAreaDescriptionComponent;
