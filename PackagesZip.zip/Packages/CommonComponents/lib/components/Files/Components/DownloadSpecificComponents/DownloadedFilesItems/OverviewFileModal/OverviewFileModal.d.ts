/// <reference types="react" />
import "./OverviewFileModal.scss";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
interface IOverviewFileModal {
    myFile: DownloadedFile;
    handleCloseOverviewModal: () => void;
    removeFile: (file: DownloadedFile) => void;
    updateFile?: (file: DownloadedFile, newName: string) => void;
    hasPermissionToEdit?: boolean;
}
declare const OverviewFileModal: ({ myFile, handleCloseOverviewModal, removeFile, updateFile, hasPermissionToEdit, }: IOverviewFileModal) => JSX.Element;
export default OverviewFileModal;
