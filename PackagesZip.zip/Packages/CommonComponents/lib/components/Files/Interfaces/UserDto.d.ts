export interface UserDto {
    userId: number;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
}
