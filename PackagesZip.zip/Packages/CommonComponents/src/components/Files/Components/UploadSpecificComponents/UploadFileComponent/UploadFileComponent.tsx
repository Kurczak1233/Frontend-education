import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";
import UploadedFilesItems from "../UploadedFilesItems/UploadedFiltesItems";
import UploadOverviewImagesComponent from "../UploadOverviewImagesComponent/UploadOverviewImagesComponent";

interface IUploadFileButton {
  setMyFiles: React.Dispatch<React.SetStateAction<File[]>>;
  myFiles: File[];
  setPreviews: React.Dispatch<React.SetStateAction<HasPreviewItem[]>>;
  previews: HasPreviewItem[];
  serachButton: JSX.Element;
}

const UploadFileComponent = ({
  setMyFiles,
  myFiles,
  serachButton,
  previews,
  setPreviews,
}: IUploadFileButton) => {
  const removeFile = (file: File) => {
    const newFiles = [...myFiles];
    newFiles.splice(newFiles.indexOf(file), 1);
    setMyFiles(newFiles);
    if (file.type.includes("image")) {
      const newPreviews = [...previews];
      newPreviews.splice(
        newPreviews.findIndex(
          (item) => item.lastModified === file.lastModified
        ),
        1
      );
      setPreviews(newPreviews);
    }
  };

  return (
    <>
      <UploadedFilesItems myFiles={myFiles} removeFile={removeFile} />
      <UploadOverviewImagesComponent previews={previews} />
      {serachButton}
    </>
  );
};

export default UploadFileComponent;
