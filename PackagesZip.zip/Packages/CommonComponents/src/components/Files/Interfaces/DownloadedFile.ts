import { ImageDetails } from "./ImageDetails";
import { UserDto } from "./UserDto";

export interface DownloadedFile {
  imageDetails: ImageDetails;
  guid: string;
  createdOn: Date;
  groupIndex: string;
  questionIndex: string;
  createdBy?: UserDto;
}
