/// <reference types="react" />
import "./ErrorText.scss";
interface IErrorText {
    isVisible: boolean;
    text: string;
}
declare const ErrorText: ({ isVisible, text }: IErrorText) => JSX.Element;
export default ErrorText;
