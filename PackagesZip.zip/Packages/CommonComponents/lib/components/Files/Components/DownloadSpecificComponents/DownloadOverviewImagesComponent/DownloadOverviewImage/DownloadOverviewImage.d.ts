/// <reference types="react" />
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
interface IDownloadOverviewImage {
    myFile: DownloadedFile;
    removeFile: (file: DownloadedFile) => void;
    isReadonly: boolean;
    updateFile?: (file: DownloadedFile, newName: string) => void;
    hasPermissionToEdit?: boolean;
}
declare const DownloadOverviewImage: ({ myFile, removeFile, updateFile, isReadonly, hasPermissionToEdit, }: IDownloadOverviewImage) => JSX.Element;
export default DownloadOverviewImage;
