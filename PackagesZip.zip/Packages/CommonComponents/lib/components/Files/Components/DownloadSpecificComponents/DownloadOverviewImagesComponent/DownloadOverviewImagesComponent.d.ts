/// <reference types="react" />
import { DownloadedFile } from "../../../Interfaces/DownloadedFile";
import "./DownloadOverviewImagesComponent.scss";
interface IDownloadOverviewImagesComponent {
    myFiles: DownloadedFile[];
    marginTop?: number;
    marginBottom?: number;
    removeFile: (file: DownloadedFile) => void;
    isReadonly?: boolean;
    setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
    organizationId: number;
    hasPermissionToEdit?: boolean;
    updateFileName(id: string, fileName: string, organizationId: number): Promise<null>;
}
declare const DownloadOverviewImagesComponent: ({ myFiles, marginBottom, marginTop, removeFile, organizationId, setOtherFiles, isReadonly, hasPermissionToEdit, updateFileName, }: IDownloadOverviewImagesComponent) => JSX.Element;
export default DownloadOverviewImagesComponent;
