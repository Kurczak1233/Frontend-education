import "./UploadedImagesButton.scss";
import SmallGreenPlusIcon from "../../../../../public/SmallGreenPlusIcon.svg";
import { useDropzone } from "react-dropzone";
import { useCallback } from "react";
import { maxFileSizeInBytes, acceptedFileExtensions } from "../../../../../constants/Files";
import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";

interface IUploadedImagesButton {
  marginTop?: number;
  marginBottom?: number;
  setPreviews: React.Dispatch<React.SetStateAction<HasPreviewItem[]>>;
  previews: HasPreviewItem[];
  setMyFiles: React.Dispatch<React.SetStateAction<File[]>>;
  myFiles: File[];
}

const UploadedImagesButton = ({
  marginTop,
  marginBottom,
  setPreviews,
  previews,
  setMyFiles,
  myFiles,
}: IUploadedImagesButton) => {
  const onDrop = useCallback(
    (acceptedFiles) => {
      setMyFiles([...myFiles, ...acceptedFiles]);
      const result = acceptedFiles.map((file: Blob | MediaSource) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      );
      const mappedImages = result.filter(
        (object: { type: string | string[] }) => object.type.includes("image")
      );
      setPreviews([...previews, ...mappedImages]);
    },
    [myFiles, previews]
  );

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    maxSize: maxFileSizeInBytes,
    accept: acceptedFileExtensions,
    multiple: false,
  });

  return (
    <div
      style={{ marginTop: marginTop, marginBottom: marginBottom }}
      className="common-components__upload-file-button"
      {...getRootProps()}
    >
      <input {...getInputProps()} />
      <img src={SmallGreenPlusIcon} alt="Green plus icon" />
      <span>add file</span>
    </div>
  );
};

export default UploadedImagesButton;
