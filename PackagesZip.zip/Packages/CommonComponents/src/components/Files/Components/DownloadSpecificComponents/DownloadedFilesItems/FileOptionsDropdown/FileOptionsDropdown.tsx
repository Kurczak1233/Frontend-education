import "./FileOptionsDropdown.scss";
import TrashCanIcon from "../../../../../../public/TrashCanIcon.svg";
import DownloadIcon from "../../../../../../public/DownloadIcon.svg";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
import { downloadFileOnClick } from "../../../../Interfaces/DownloadFileOnClick";

interface IFileOptionsDropdown {
  myFile: DownloadedFile;
  setIsFileDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>;
  handleOpenDeleteModal: () => void;
}

const FileOptionsDropdown = ({
  myFile,
  setIsFileDropdownOpen,
  handleOpenDeleteModal,
}: IFileOptionsDropdown) => {
  const handleDownloadFile = () => {
    setIsFileDropdownOpen(false);
    downloadFileOnClick(myFile);
  };

  return (
    <div className="common-components__file-options-dropdown">
      <div
        className="common-components__file-options-download"
        onClick={handleDownloadFile}
      >
        <img src={DownloadIcon} alt={"Download icon"} />
        Download
      </div>
      <div
        className="common-components__file-options-delete"
        onClick={handleOpenDeleteModal}
      >
        <img src={TrashCanIcon} alt={"Trash icon"} />
        Delete
      </div>
    </div>
  );
};

export default FileOptionsDropdown;
