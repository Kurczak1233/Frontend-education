import TrashCanIcon from "../../../../../public/TrashCanIcon.svg";
import FileIcon from "../../../../../constants/FileIcon/FileIcon";
import "./UploadedFilesItems.scss";

interface IUploadedFilesItems {
  myFiles: File[];
  removeFile: (file: File) => void;
}

const UploadedFilesItems = ({ myFiles, removeFile }: IUploadedFilesItems) => {
  return (
    <div className="common-components__files-text-wrapper">
      {myFiles &&
        myFiles.map((myFile) => (
          <div
            className="common-components__files-item"
            key={`${myFile.name} ${myFile.lastModified}`}
          >
            <div className="common-components__files-item--left">
              <FileIcon contentType={myFile.type} />
              <span>{myFile.name}</span>
            </div>
            <div className="common-components__files-item--right">
              <img
                src={TrashCanIcon}
                alt="Trash icon"
                onClick={() => removeFile(myFile)}
                className="delete-file"
              />
            </div>
          </div>
        ))}
    </div>
  );
};

export default UploadedFilesItems;
