import React from "react";
import "./CalendarComponent.scss";
interface ICalendarComponent {
    isOpen: boolean;
    isOpenSetter: React.Dispatch<React.SetStateAction<boolean>>;
    date: Date | null;
    onSaveClick: (date: Date | null) => void;
}
declare const CalendarComponent: ({ isOpen, isOpenSetter, date, onSaveClick, }: ICalendarComponent) => JSX.Element;
export default CalendarComponent;
