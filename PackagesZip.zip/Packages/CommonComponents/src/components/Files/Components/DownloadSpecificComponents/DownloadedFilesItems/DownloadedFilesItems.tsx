import "./DownloadedFilesItems.scss";
import DownloadedFileItem from "./DownloadedFileItem/DownloadedFileItem";
import { DownloadedFile } from "../../../Interfaces/DownloadedFile";

interface IDownloadedFilesItems {
  myFiles: DownloadedFile[];
  removeFile: (file: DownloadedFile) => void;
  isImageUploading: boolean;
  isReadonly?: boolean;
  showDropdown?: boolean;
  hasPermissionsToEdit?: boolean;
  setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
  organizationId: number;
  updateFileName(id: string, fileName: string, organizationId: number): Promise<null>;
}

const DownloadedFilesItems = ({
  myFiles,
  removeFile,
  isImageUploading,
  isReadonly = false,
  showDropdown = true,
  hasPermissionsToEdit = true,
  setOtherFiles,
  organizationId,
  updateFileName,
}: IDownloadedFilesItems) => {
  return (
    <div className="common-components__downloaded-files-text-wrapper">
      {myFiles &&
        myFiles.map((myFile) => (
          <DownloadedFileItem
            myFile={myFile}
            isReadonly={isReadonly}
            removeFile={removeFile}
            key={`${myFile.imageDetails.fileDownloadName} ${myFile.createdOn}`}
            showDropdown={showDropdown}
            hasPermissionToEdit={hasPermissionsToEdit}
            setOtherFiles={setOtherFiles}
            organizationId={organizationId}
            updateFileName={updateFileName}
          />
        ))}
      {isImageUploading && (
        <div className="common-components__downloaded-files-item">
          Loading...
        </div>
      )}
    </div>
  );
};

export default DownloadedFilesItems;
