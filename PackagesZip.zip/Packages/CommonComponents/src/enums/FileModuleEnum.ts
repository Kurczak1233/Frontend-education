export enum FileModuleEnum {
  Tasks = 1,
  UserDocuments = 2,
  UserCompetencies = 3,
  Deviation = 4,
  Equipment = 5,
  ChangeEvent = 6,
  ChecklistAnswer = 7,
  OrganizationLogo = 8,
  EquipmentImage = 9,
  OrganizationUserImage = 10, 
  ProjectDocuments = 11,
  OrganizationDocuments = 12
}
