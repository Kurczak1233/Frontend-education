Important!

This package is using a typescript transpilator which allows us to build all dynamic files (ts/tsx -> js).
The static files like css, scss or html files will not be included inside the package!
Source link: https://vccolombo.github.io/blog/tsc-how-to-copy-non-typescript-files-when-building/

At the moment, the only option it to copy scss files. To expand the static files add more rules in tsconfig.json.

To correctly publish packages you have to transpile the ts to js first and then copy rest of static files to the lib (our build) folder.
0. Remember to be logged in and have npm account.
1. npm run build
2. npm run copy-files
3. Increment version in package.json
4. npm publish


How to use components?

The components are created in order to provide a reuseable source of components. The params are extracted mainly using react-hook-form - register hook which provides better performance for inputs operation. For other less common please read the possible params to send. It may provide some different solutions for your purpose.

Possible problems:
1. The placeholder does not fit appropriate font size.
Solution: For both app it may be hard to adjust dynamically placeholder size. For this reason try to add additional class in your parent component which will be focusing on the placeholder of the common component, or you may just set the global textarea placeholder size.
2. I want to add a dynamic font in the label but I still want to use register hook.
Solution: There is a special label called labelWithVariables created. Please take a look on that param.