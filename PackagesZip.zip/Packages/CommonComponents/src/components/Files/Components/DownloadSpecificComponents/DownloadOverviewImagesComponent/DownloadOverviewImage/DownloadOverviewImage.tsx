import { useState } from "react";
import Modal from "react-modal";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
import OverviewFileModal from "../../DownloadedFilesItems/OverviewFileModal/OverviewFileModal";

interface IDownloadOverviewImage {
  myFile: DownloadedFile;
  removeFile: (file: DownloadedFile) => void;
  isReadonly: boolean;
  updateFile?: (file: DownloadedFile, newName: string) => void;
  hasPermissionToEdit?: boolean;
}

const DownloadOverviewImage = ({
  myFile,
  removeFile,
  updateFile,
  isReadonly,
  hasPermissionToEdit,
}: IDownloadOverviewImage) => {
  const [isOverviewFileModalOpen, setIsOverviewFileModalOpen] =
    useState<boolean>(false);

  const handleCloseOverviewModal = () => {
    setIsOverviewFileModalOpen(false);
  };

  const handleOpenOverviewModal = () => {
    if (!isReadonly) {
      setIsOverviewFileModalOpen(true);
    }
  };
  return (
    <>
      <Modal
        isOpen={isOverviewFileModalOpen}
        onRequestClose={handleCloseOverviewModal}
        className={"common-components__overview-file-modal"}
        overlayClassName={"common-components__overview-file-modal-overlay"}
        ariaHideApp={false}
      >
        <OverviewFileModal
          myFile={myFile}
          updateFile={updateFile}
          handleCloseOverviewModal={handleCloseOverviewModal}
          removeFile={removeFile}
          hasPermissionToEdit={hasPermissionToEdit}
        />
      </Modal>
      <img
        onClick={handleOpenOverviewModal}
        className="common-components__upload-image"
        src={`data:image/png;base64,${myFile.imageDetails.fileContents}`}
        alt={"overview image"}
        width={120}
        height={120}
      />
    </>
  );
};

export default DownloadOverviewImage;
