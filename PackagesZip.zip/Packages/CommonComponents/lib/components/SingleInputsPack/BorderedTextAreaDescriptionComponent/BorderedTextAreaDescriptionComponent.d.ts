/// <reference types="react" />
import { FieldError, UseFormRegister } from "react-hook-form";
import "./BorderedTextAreaDescriptionComponent.scss";
interface IBorderedTextAreaDescriptionComponent {
    marginTop?: number;
    register: UseFormRegister<any>;
    requirements?: any;
    registerName?: string;
    marginBottom?: number;
    hideLabel?: boolean;
    disabled?: boolean;
    label: string;
    fontSize?: number;
    labelSize?: number;
    width?: number;
    height?: number;
    fieldError?: FieldError | undefined;
    errorText?: string;
    required?: boolean;
    datacy?: string;
}
declare const BorderedTextAreaDescriptionComponent: ({ marginBottom, marginTop, register, requirements, registerName, label, fontSize, labelSize, height, hideLabel, disabled, width, fieldError, errorText, required, datacy, }: IBorderedTextAreaDescriptionComponent) => JSX.Element;
export default BorderedTextAreaDescriptionComponent;
