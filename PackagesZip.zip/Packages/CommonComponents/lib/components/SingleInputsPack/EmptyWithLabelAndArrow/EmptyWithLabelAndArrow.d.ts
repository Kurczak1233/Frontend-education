/// <reference types="react" />
import "./EmptyWithLabelAndArrow.scss";
interface InputWithLabel {
    label: string;
    containerPlaceholder: string;
    marginTop?: number;
    marginBottom?: number;
    isActive?: boolean;
    onClick: () => void;
}
declare const EmptyWithLabelAndArrow: ({ label, containerPlaceholder, marginTop, marginBottom, isActive, onClick, }: InputWithLabel) => JSX.Element;
export default EmptyWithLabelAndArrow;
