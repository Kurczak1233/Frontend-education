declare const isNullOrWhiteSpace: (string: string) => boolean;
export default isNullOrWhiteSpace;
