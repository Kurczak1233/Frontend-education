/// <reference types="react" />
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";
import "./DeleteFileModal.scss";
interface IDeleteFileModal {
    removeFile: (file: DownloadedFile) => void;
    myFile: DownloadedFile;
    setIsFileDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>;
    handleCloseDeleteModal: () => void;
    setIsDeleteFileModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
    handleCloseOverviewModal?: () => void;
}
declare const DeleteFileModal: ({ removeFile, myFile, setIsFileDropdownOpen, handleCloseDeleteModal, setIsDeleteFileModalOpen, handleCloseOverviewModal, }: IDeleteFileModal) => JSX.Element;
export default DeleteFileModal;
