import WhiteCrossIcon from "../../../../../../public/WhiteCrossIcon.svg";
import WhiteThreeDotsIcon from "../../../../../../public/WhiteThreeDotsIcon.svg";
import { useState } from "react";
import DeleteFileModal from "../DeleteFileModal/DeleteFileModal";
import FileOptionsDropdown from "../FileOptionsDropdown/FileOptionsDropdown";
import "./OverviewFileModal.scss";
import Modal from "react-modal";
import DropdownWrapper from "../../../../../DropdownWrapper/DropdownWrapper";
import { DownloadedFile } from "../../../../Interfaces/DownloadedFile";

interface IOverviewFileModal {
  myFile: DownloadedFile;
  handleCloseOverviewModal: () => void;
  removeFile: (file: DownloadedFile) => void;
  updateFile?: (file: DownloadedFile, newName: string) => void;
  hasPermissionToEdit?: boolean;
}

const OverviewFileModal = ({
  myFile,
  handleCloseOverviewModal,
  removeFile,
  updateFile,
  hasPermissionToEdit = true,
}: IOverviewFileModal) => {
  const [isFileDropdownOpen, setIsFileDropdownOpen] = useState<boolean>(false);
  const [isDeleteFileModalOpen, setIsDeleteFileModalOpen] =
    useState<boolean>(false);
  const [fileName, setFileName] = useState<string>(
    myFile.imageDetails.fileDownloadName.length > 40
      ? myFile.imageDetails.fileDownloadName.slice(0, 40)
      : myFile.imageDetails.fileDownloadName
  );

  const openFileDropdown = () => {
    setIsFileDropdownOpen(true);
  };

  const handleCloseDeleteModal = () => {
    setIsDeleteFileModalOpen(false);
  };

  const handleOpenDeleteModal = () => {
    setIsDeleteFileModalOpen(true);
  };

  const onNameChange = (newName: string) => {
    updateFile && updateFile(myFile, newName);
  };

  return (
    <>
      <Modal
        isOpen={isDeleteFileModalOpen}
        onRequestClose={handleCloseDeleteModal}
        className={"common-components__delete-file-modal"}
        overlayClassName={"common-components__delete-file-modal-overlay"}
        ariaHideApp={false}
      >
        <DeleteFileModal
          removeFile={removeFile}
          myFile={myFile}
          setIsDeleteFileModalOpen={setIsDeleteFileModalOpen}
          handleCloseDeleteModal={handleCloseDeleteModal}
          setIsFileDropdownOpen={setIsFileDropdownOpen}
          handleCloseOverviewModal={handleCloseOverviewModal}
        />
      </Modal>
      <div className="common-components__overview-file">
        <div className="common-components__overview-file-heading">
          {hasPermissionToEdit ? (
            <input
              className="common-components__input--wrapper"
              placeholder={"Image name..."}
              value={fileName}
              onChange={(e) => {
                setFileName(e.target.value);
              }}
              onBlur={(e) => {
                onNameChange(e.target.value);
              }}
            />
          ) : (
            <div className="common-components__overview-file-heading-title">
              {fileName}
            </div>
          )}
          {hasPermissionToEdit && (
            <div className="common-components__overview-file-heading-images">
              <div>
                <DropdownWrapper
                  isOpen={isFileDropdownOpen}
                  setIsOpen={setIsFileDropdownOpen}
                  dropdownContent={
                    <FileOptionsDropdown
                      handleOpenDeleteModal={handleOpenDeleteModal}
                      myFile={myFile}
                      setIsFileDropdownOpen={setIsFileDropdownOpen}
                    />
                  }
                  dropdownContainer={
                    <img
                      src={WhiteThreeDotsIcon}
                      alt="OptionsIcon"
                      onClick={openFileDropdown}
                    />
                  }
                />
              </div>
            </div>
          )}
          <div className="common-components__overview-file-heading-exit-icon">
            <img
              src={WhiteCrossIcon}
              onClick={handleCloseOverviewModal}
              alt="Exit icon"
            />
          </div>
        </div>
        <img
          className="common-components__overview-image"
          src={`data:image/png;base64,${myFile.imageDetails.fileContents}`}
        />
      </div>
    </>
  );
};

export default OverviewFileModal;
