/// <reference types="react" />
import "./DropdownWrapper.scss";
interface IDropdownWrapper {
    isOpen: boolean;
    setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
    dropdownContent?: JSX.Element;
    dropdownContainer: JSX.Element;
    maxWidth?: boolean;
}
declare const DropdownWrapper: ({ isOpen, setIsOpen, dropdownContent, dropdownContainer, maxWidth, }: IDropdownWrapper) => JSX.Element;
export default DropdownWrapper;
