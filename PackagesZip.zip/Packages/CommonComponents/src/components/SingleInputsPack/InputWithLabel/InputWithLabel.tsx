import { useState } from "react";
import { FieldError, UseFormRegister } from "react-hook-form";
import ErrorText from "../../ErrorText/ErrorText";
import "./InputWithLabel.scss";

interface IInputWithLabel {
  label: any;
  labelWithVariables?: string;
  inputPlaceholder: string;
  showCalendarIcon?: boolean;
  isFirstCalendarInput?: boolean;
  marginTop?: number;
  marginBottom?: number;
  showSignsCounter?: boolean;
  maxInputLength?: number;
  type?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register: UseFormRegister<any>;
  requirements?: any;
  fieldError?: FieldError | undefined;
  errorText?: string;
  value?: string | number;
  registerName?: string;
  onValueChange?: (value: string) => void;
  onBlur?: (value: string, index?: number) => void;
  min?: number;
  pattern?: string;
  index?: number;
  inputMode?: string;
  fontSize?: number;
  labelSize?: number;
  disabled?: boolean;
  width?: number;
  height?: string;
  required?: boolean;
  datacy?: string;
}

const InputWithLabel = ({
  label,
  labelWithVariables,
  inputPlaceholder,
  showCalendarIcon,
  isFirstCalendarInput,
  marginTop,
  marginBottom,
  showSignsCounter,
  maxInputLength,
  register,
  fieldError,
  errorText,
  requirements,
  type,
  value,
  registerName,
  onValueChange,
  min,
  onBlur,
  index,
  pattern,
  inputMode,
  fontSize = 14,
  labelSize = 14,
  disabled = false,
  height = "48px",
  width,
  required = false,
  datacy,
}: IInputWithLabel) => {
  const [counter, setCounter] = useState<number>(0);

  const updateSignsCounter = (inputValue: string) => {
    setCounter(inputValue.length);
  };

  return (
    <div
      className={"common-components__input-with-label-wrapper"}
      style={{
        paddingRight: isFirstCalendarInput ? "10px" : "0px",
        paddingLeft: showCalendarIcon && !isFirstCalendarInput ? "10px" : "0px",
        marginTop: marginTop,
        marginBottom: marginBottom,
      }}
    >
      <div
        style={{ fontSize: labelSize }}
        className={"common-components__input-with-label"}
      >
        <span>
          {labelWithVariables ? labelWithVariables : label}
          {required && (
            <span className="common-components__required-star">*</span>
          )}
        </span>
        <div className="common-components__error-text">
          <ErrorText
            isVisible={fieldError !== undefined}
            text={errorText ? errorText : ""}
          />
        </div>
        {showSignsCounter && <span>{counter}/500</span>}
      </div>
      {onBlur ? (
        <input
          data-cy={datacy}
          id={"inputWithLabel"}
          type={type}
          min={min}
          style={{
            fontSize: fontSize,
            width: width ? `${width}px` : "100%",
            height: height ? height : "48px",
          }}
          maxLength={maxInputLength}
          {...register(registerName ? registerName : label, requirements)}
          onChange={(e) => {
            updateSignsCounter(e.target.value);
            if (onValueChange) {
              onValueChange(e.target.value);
            }
          }}
          onBlur={(e) => {
            if (onBlur) {
              onBlur(e.target.value, index);
            }
          }}
          pattern={pattern}
          inputMode={inputMode ? "numeric" : "text"}
          className={`${"common-components__input-with-label-input"} + ${
            showCalendarIcon &&
            "common-components__input-with-label-show-calendar-icon"
          }`}
          placeholder={inputPlaceholder}
          value={value}
          disabled={disabled}
        />
      ) : onchange ? (
        <input
          data-cy={datacy}
          style={{
            fontSize: fontSize,
            width: width ? `${width}px` : "100%",
            height: height ? height : "48px",
          }}
          id={"inputWithLabel"}
          type={type}
          min={min}
          maxLength={maxInputLength}
          {...register(registerName ? registerName : label, requirements)}
          onChange={(e) => {
            updateSignsCounter(e.target.value);
            if (onValueChange) {
              onValueChange(e.target.value);
            }
          }}
          className={`${"common-components__input-with-label-input"} + ${
            showCalendarIcon &&
            "common-components__input-with-label-show-calendar-icon"
          }`}
          inputMode={inputMode ? "numeric" : "text"}
          placeholder={inputPlaceholder}
          value={value}
          disabled={disabled}
        />
      ) : (
        <input
          data-cy={datacy}
          style={{
            fontSize: fontSize,
            width: width ? `${width}px` : "100%",
            height: height ? height : "48px",
          }}
          id={"inputWithLabel"}
          type={type}
          min={min}
          maxLength={maxInputLength}
          {...register(registerName ? registerName : label, requirements)}
          className={`${"common-components__input-with-label-input"} + ${
            showCalendarIcon &&
            "common-components__input-with-label-show-calendar-icon"
          }`}
          inputMode={inputMode ? "numeric" : "text"}
          placeholder={inputPlaceholder}
          value={value}
          disabled={disabled}
        />
      )}
    </div>
  );
};

export default InputWithLabel;
