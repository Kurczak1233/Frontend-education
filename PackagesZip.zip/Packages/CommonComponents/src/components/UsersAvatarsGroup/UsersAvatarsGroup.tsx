import { AvatarGroup } from "@mui/material";
import { getDisplayNameOfUser } from "./GetDisplayNameOfUser";
import UserAvatar from "../UserAvatar/UserAvatar";
import "./UsersAvatarsGroup.scss";

interface IUsersAvatarsGroup {
  size: number;
  users: {
    firstName: string;
    lastName: string;
    email: string;
  }[];
  maxAvatarsNumber: number;
}

const UsersAvatarsGroup = ({
  size,
  users,
  maxAvatarsNumber,
}: IUsersAvatarsGroup) => {
  return (
    <AvatarGroup
      max={maxAvatarsNumber}
      classes={{ avatar: `rest-of-avatars-label--size-${size}px` }}
    >
      {users &&
        users.map((user) => {
          return (
            <UserAvatar
              key={user.email}
              displayName={getDisplayNameOfUser(
                user.firstName,
                user.lastName,
                user.email
              )}
              size={size}
            />
          );
        })}
    </AvatarGroup>
  );
};

export default UsersAvatarsGroup;
