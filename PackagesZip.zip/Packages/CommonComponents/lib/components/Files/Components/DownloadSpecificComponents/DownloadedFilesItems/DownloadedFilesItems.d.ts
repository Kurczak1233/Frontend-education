/// <reference types="react" />
import "./DownloadedFilesItems.scss";
import { DownloadedFile } from "../../../Interfaces/DownloadedFile";
interface IDownloadedFilesItems {
    myFiles: DownloadedFile[];
    removeFile: (file: DownloadedFile) => void;
    isImageUploading: boolean;
    isReadonly?: boolean;
    showDropdown?: boolean;
    hasPermissionsToEdit?: boolean;
    setOtherFiles: React.Dispatch<React.SetStateAction<DownloadedFile[]>>;
    organizationId: number;
    updateFileName(id: string, fileName: string, organizationId: number): Promise<null>;
}
declare const DownloadedFilesItems: ({ myFiles, removeFile, isImageUploading, isReadonly, showDropdown, hasPermissionsToEdit, setOtherFiles, organizationId, updateFileName, }: IDownloadedFilesItems) => JSX.Element;
export default DownloadedFilesItems;
