import { useEffect, useRef } from "react";
import "./DropdownWrapper.scss";

interface IDropdownWrapper {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  dropdownContent?: JSX.Element;
  dropdownContainer: JSX.Element;
  maxWidth?: boolean;
}

const DropdownWrapper = ({
  isOpen,
  setIsOpen,
  dropdownContent,
  dropdownContainer,
  maxWidth,
}: IDropdownWrapper) => {
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const checkIfClickedOutside = (e: { target: any }): void => {
      if (
        isOpen &&
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", checkIfClickedOutside);
    return () => {
      document.removeEventListener("mousedown", checkIfClickedOutside);
    };
  });

  return (
    <div
      className="dropdown-wrapper"
      ref={dropdownRef}
      style={{ width: maxWidth ? "100%" : "" }}
    >
      {dropdownContainer}
      {isOpen && dropdownContent}
    </div>
  );
};

export default DropdownWrapper;
