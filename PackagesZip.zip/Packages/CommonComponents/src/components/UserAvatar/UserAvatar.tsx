import { Avatar, Tooltip } from "@mui/material";
import React from "react";
import isNullOrWhiteSpace from "../UsersAvatarsGroup/IsNullOrEmpty";

interface IUserAvatar {
  displayName: string;
  size: number;
}

const UserAvatar = ({ displayName, size }: IUserAvatar) => {
  const convertStringToRGBColor = (string: string): string => {
    let hash = 0;
    let i;

    for (i = 0; i < string.length; i += 1) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }

    let color = "#";

    for (i = 0; i < 3; i += 1) {
      const value = (hash >> (i * 8)) & 0xff;
      color += `00${value.toString(16)}`.substr(-2);
    }

    return color;
  };

  const stringAvatar = (name: string) => {
    let label = "";
    if (name.includes("@")) {
      label = getLabelFromEmail(name);
    } else {
      const splittedName = name.replace(/ /g,'').replace(/([a-z])([A-Z])/g, '$1 $2').split(" ");
      const length = splittedName.length;

      if (length === 1) {
        label = splittedName[0][0].toUpperCase();
      } else {
        label = getInitialsFromFirstNameAndLastName(splittedName);
      }
    }

    return {
      sx: {
        bgcolor: convertStringToRGBColor(name),
        width: size,
        height: size,
        fontSize: size / 2 - 3,
        fontWeight: 600,
      },
      children: label,
    };

  };

  const getLabelFromEmail = (email: string): string => {
    const firstPartOfEmail = email.split("@")[0];
    const firstPartOfEmailSplittedByDot = firstPartOfEmail.trim().split(".");

    if (firstPartOfEmailSplittedByDot.length === 2) {
      return getInitialsFromFirstNameAndLastName(firstPartOfEmailSplittedByDot);
    }

    return firstPartOfEmail[0].toUpperCase();
  };

  const getInitialsFromFirstNameAndLastName = (
    splittedNameAndLastName: string[]
  ): string => {
    return `${splittedNameAndLastName[0][0].toUpperCase()}${splittedNameAndLastName[1][0].toUpperCase()}`;
  };

  return (<>
    {!isNullOrWhiteSpace(displayName) ? (
    <Tooltip title={displayName}>
      <Avatar alt={displayName} {...stringAvatar(displayName)} />
    </Tooltip>
    ) : (<></>)}
    </>
  );
};

export default UserAvatar;
