import { HasPreviewItem } from "../../../Interfaces/HasPreviewItem";
import "./UploadOverviewImagesComponent.scss";
interface IUploadOverviewImagesComponents {
  previews: HasPreviewItem[];
}

const UploadOverviewImagesComponent = ({
  previews,
}: IUploadOverviewImagesComponents) => {
  return (
    <div
      className="common-components__images-uploaded-wrapper"
      style={{ height: previews.length > 0 ? 136 : 36 }}
    >
      <span className="common-components__images-uploaded-no-items">
        {previews.length === 0 && "None"}
      </span>
      {previews.map((item) => {
        return (
          <img
            className="common-components__upload-image-uploaded"
            key={item.preview}
            src={item.preview}
            alt={"test"}
            width={120}
            height={120}
          />
        );
      })}
    </div>
  );
};

export default UploadOverviewImagesComponent;
